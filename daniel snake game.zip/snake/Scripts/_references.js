﻿/// <autosync enabled="true" />
/// <reference path="../js/assets.js" />
/// <reference path="../js/jquery-2.2.3.js" />
/// <reference path="../js/main.js" />
/// <reference path="../js/objects.js" />
/// <reference path="../js/vector2.js" />
/// <reference path="../reference/wbr37.js" />
